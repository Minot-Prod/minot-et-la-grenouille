import PostFeedLayout from '../PostFeedLayout';
export default PostFeedLayout;
